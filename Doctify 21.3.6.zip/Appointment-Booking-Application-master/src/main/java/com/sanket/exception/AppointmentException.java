package com.sanket.exception;

public class AppointmentException extends Exception{
	
	public AppointmentException() {
	
	}
	
	public AppointmentException(String msg) {
		
		super(msg);
		
	}

}
