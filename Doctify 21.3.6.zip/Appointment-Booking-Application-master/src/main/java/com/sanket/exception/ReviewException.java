package com.sanket.exception;

public class ReviewException extends Exception {
	
	public ReviewException() {
		
	}
	
	
	public ReviewException(String msg) {
		super(msg);
	}

}
